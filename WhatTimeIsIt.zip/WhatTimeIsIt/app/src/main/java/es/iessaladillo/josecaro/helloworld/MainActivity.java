package es.iessaladillo.josecaro.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

import static java.text.DateFormat.*;

public class MainActivity extends AppCompatActivity {


    SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat formatHour = new SimpleDateFormat("HH:mm");
    Date date = new Date();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView lblDate = findViewById(R.id.lblDate);
        TextView lblHour = findViewById(R.id.lblHour);


        lblDate.setText(formatDate.format(date));
        lblHour.setText(formatHour.format(date));

    }
}